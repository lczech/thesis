copied from /home/lucas/Projects/bacardi/01_backbone/09_viz_dispersion/bv
and /home/lucas/Projects/bacardi/01_backbone/09_viz_dispersion/bv/var_test_10
